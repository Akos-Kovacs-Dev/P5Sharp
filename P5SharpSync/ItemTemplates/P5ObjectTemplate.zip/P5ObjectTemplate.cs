﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using P5Sharp;
using SkiaSharp;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : P5Object
    {
         

        protected override void Draw()
        {
          
        }
    }
}
