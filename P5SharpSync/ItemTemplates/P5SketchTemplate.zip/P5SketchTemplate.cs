﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using P5Sharp;
using SkiaSharp;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : SketchBase
    {
        protected override void Setup()
        {

        }

        protected override void Draw()
        {
            Background(51);
        }
    }
}
